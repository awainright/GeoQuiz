package Fitscore;

import android.content.Intent;
import android.support.v4.app.Fragment;

public class AthleteListActivity extends SingleFragmentActivity
        implements AthleteListFragment.Callbacks, AthleteFragment.Callbacks {
    @Override
    protected Fragment createFragment() {
        return new AthleteListFragment();
    }

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_masterdetail;
    }

    @Override
    public void onAthleteSelected(Athlete athlete) {
        if (findViewById(R.id.detail_fragment_container) == null) {
            Intent intent = AthletePagerActivity.newIntent(this, athlete.getId());
            startActivity(intent);
        } else {
            Fragment newDetail = AthleteFragment.newInstance(athlete.getId());
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.detail_fragment_container, newDetail)
                    .commit();
        }
    }

    @Override
    public void onAthleteUpdated(Athlete athlete) {
        AthleteListFragment listFragment = (AthleteListFragment) getSupportFragmentManager().findFragmentById(R.id.fragment_container);
        listFragment.updateUI();
    }
}
