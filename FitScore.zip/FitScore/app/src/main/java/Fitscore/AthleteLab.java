package Fitscore;

import Fitscore.database.AthleteBaseHelper;
import Fitscore.database.AthleteCursorWrapper;
import Fitscore.database.AthleteDbSchema;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class AthleteLab {
    private static AthleteLab sAthleteLab;

    private Context mContext;
    private SQLiteDatabase mDatabase;

    public static AthleteLab get(Context context) {
        if (sAthleteLab == null) {
            sAthleteLab = new AthleteLab(context);
        }
        return sAthleteLab;
    }

    private AthleteLab(Context context) {
        mContext = context.getApplicationContext();
        mDatabase = new AthleteBaseHelper(mContext).getWritableDatabase();
    }

    public void addAthlete(Athlete athlete) {
        ContentValues values = getContentValues(athlete);
        mDatabase.insert(AthleteDbSchema.AthleteTable.NAME, null, values);
    }

    public void updateAthlete(Athlete athlete) {
        String uuidString = athlete.getId().toString();
        ContentValues values = getContentValues(athlete);

        mDatabase.update(AthleteDbSchema.AthleteTable.NAME, values, AthleteDbSchema.AthleteTable.Cols.UUID + " = ?", new String[] { uuidString});
    }

    public AthleteCursorWrapper queryAthletes(String whereClause, String[] whereArgs) {
        Cursor cursor = mDatabase.query(
                AthleteDbSchema.AthleteTable.NAME,
                null,
                whereClause,
                whereArgs,
                null,
                null,
                null
        );

        return new AthleteCursorWrapper(cursor);
    }

    public List<Athlete> getAthletes() {
        List<Athlete> athletes = new ArrayList<>();

        AthleteCursorWrapper cursor = queryAthletes(null, null);

        try {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                athletes.add(cursor.getAthlete());
                cursor.moveToNext();
            }
        } finally {
            cursor.close();
        }

        return athletes;
    }

    public Athlete getAthlete(UUID id) {
        AthleteCursorWrapper cursor = queryAthletes(AthleteDbSchema.AthleteTable.Cols.UUID + " = ?", new String[] { id.toString() });

        try {
            if (cursor.getCount() == 0) {
                return null;
            }
            cursor.moveToFirst();
            return cursor.getAthlete();
        } finally {
            cursor.close();
        }
    }

    public File getPhotoFile(Athlete athlete) {
        File filesDir = mContext.getFilesDir();
        return new File(filesDir, athlete.getPhotoFilename());
    }

    private static ContentValues getContentValues(Athlete athlete) {
        ContentValues values = new ContentValues();
        values.put(AthleteDbSchema.AthleteTable.Cols.UUID, athlete.getId().toString());
        values.put(AthleteDbSchema.AthleteTable.Cols.FIRSTNAME, athlete.getFirstName());
        values.put(AthleteDbSchema.AthleteTable.Cols.FIRSTNAME, athlete.getLastName());
        values.put(AthleteDbSchema.AthleteTable.Cols.GENDER, athlete.getGender());
        values.put(AthleteDbSchema.AthleteTable.Cols.COMPLIANCE, athlete.getCompliance());
        values.put(AthleteDbSchema.AthleteTable.Cols.CLEAN, athlete.getClean());
        values.put(AthleteDbSchema.AthleteTable.Cols.SNATCH, athlete.getSnatch());
        values.put(AthleteDbSchema.AthleteTable.Cols.BACKSQUAT, athlete.getBackSquat());
        values.put(AthleteDbSchema.AthleteTable.Cols.DEADLIFT, athlete.getDeadlift());
        values.put(AthleteDbSchema.AthleteTable.Cols.ROW, athlete.getRow());
        values.put(AthleteDbSchema.AthleteTable.Cols.RUN, athlete.getRun());
        values.put(AthleteDbSchema.AthleteTable.Cols.BODYWEIGHT, athlete.getBodyWeight());
        values.put(AthleteDbSchema.AthleteTable.Cols.FITSCORE, athlete.getFitScore());

        return values;
    }
}
