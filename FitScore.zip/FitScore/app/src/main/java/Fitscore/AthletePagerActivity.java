package Fitscore;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;


import java.util.List;
import java.util.UUID;

public class AthletePagerActivity extends AppCompatActivity implements AthleteFragment.Callbacks {

    private static final String EXTRA_CRIME_ID =
            "fitscore.athlete_id";

    private ViewPager mViewPager;
    private List<Athlete> mAthlete;


    public static Intent newIntent(Context packageContext, UUID athleteId) {
        Intent intent = new Intent(packageContext, AthletePagerActivity.class);
        intent.putExtra(EXTRA_CRIME_ID, athleteId);
        return intent;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_athlete_pager);

        UUID athleteId = (UUID) getIntent().getSerializableExtra(EXTRA_CRIME_ID);

        mViewPager = findViewById(R.id.athlete_view_pager);

        mAthlete = AthleteLab.get(this).getAthletes();

        FragmentManager fragmentManager = getSupportFragmentManager();
        mViewPager.setAdapter(new FragmentStatePagerAdapter(fragmentManager) {
            @Override
            public Fragment getItem(int position) {
                Athlete athlete = mAthlete.get(position);
                return AthleteFragment.newInstance(athlete.getId());
            }

            @Override
            public int getCount() {
                return mAthlete.size();
            }
        });

        for (int i = 0; i < mAthlete.size(); ++i) {
            if (mAthlete.get(i).getId().equals(athleteId)) {
                mViewPager.setCurrentItem(i);
                break;
            }
        }
    }

    @Override
    public void onAthleteUpdated(Athlete athlete) {

    }
}
