package Fitscore;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.*;
import android.widget.TextView;


import java.util.List;

public class AthleteListFragment extends Fragment {
    private static final String SAVED_SUBTITLE_VISIBLE = "subtitle";
    private static final String TAG = "AthleteListFragment";

    private RecyclerView mAthleteRecyclerView;
    private AthleteAdapter mAdapter;
    private boolean mSubtitleVisible;

    private Callbacks mCallbacks;

    /**
     * Required interface for hosting activities
     */
    public interface Callbacks {
        void onAthleteSelected(Athlete athlete);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mCallbacks = (Callbacks) context;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_athlete_list, container, false);

        mAthleteRecyclerView = view.findViewById(R.id.athlete_recycler_view);
        mAthleteRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        if (savedInstanceState != null) {
            mSubtitleVisible = savedInstanceState.getBoolean(SAVED_SUBTITLE_VISIBLE, false);
        }

        updateUI();

        return view;
    }

    public void updateUI() {
        AthleteLab athleteLab = AthleteLab.get(getActivity());
        List<Athlete> athletes = athleteLab.getAthletes();

        if (mAdapter == null) {
            mAdapter = new AthleteAdapter(athletes);
            mAthleteRecyclerView.setAdapter(mAdapter);
        } else {
            mAdapter.setAthletes(athletes);
            mAdapter.notifyDataSetChanged();
        }

        updateSubtitle();
    }

    @Override
    public void onResume()
    {
        super.onResume();
        updateUI();
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.fragment_athlete_list, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.new_athlete:
                Athlete athlete = new Athlete();
                AthleteLab.get(getActivity()).addAthlete(athlete);
                updateUI();
                mCallbacks.onAthleteSelected(athlete);
                return true;
            case R.id.show_subtitle:
                mSubtitleVisible = !mSubtitleVisible;
                getActivity().invalidateOptionsMenu();
                updateSubtitle();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void updateSubtitle() {
        AthleteLab athleteLab = AthleteLab.get(getActivity());
        int athleteCount = athleteLab.getAthletes().size();
        String subtitle = getString(R.string.subtitle_format, athleteCount);

        if (!mSubtitleVisible) {
            subtitle = null;
        }

        AppCompatActivity activity = (AppCompatActivity) getActivity();
        activity.getSupportActionBar().setSubtitle(subtitle);
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean(SAVED_SUBTITLE_VISIBLE, mSubtitleVisible);
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mCallbacks = null;
    }

    private class AthleteHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private TextView mFirstNameTextView;
        private TextView mLastNameTextView;


        private Athlete mAthlete;

        public AthleteHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.list_item_athlete, parent, false));
            itemView.setOnClickListener(this);

            mFirstNameTextView = itemView.findViewById(R.id.athlete_firstname);
            mLastNameTextView = itemView.findViewById(R.id.athlete_lastname);

        }

        public void bind(Athlete athlete) {
            mAthlete = athlete;
            mFirstNameTextView.setText(mAthlete.getFirstName());
            mLastNameTextView.setText(mAthlete.getLastName());

        }

        @Override
        public void onClick(View v) {
            mCallbacks.onAthleteSelected(mAthlete);
        }
    }

    private class AthleteAdapter extends RecyclerView.Adapter<AthleteHolder> {
        private List<Athlete> mAthlete;

        public AthleteAdapter(List<Athlete> athletes) {
            mAthlete = athletes;
        }

        @NonNull
        @Override
        public AthleteHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//            Log.d(TAG, "In onCreateViewHolder");
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());
            return new AthleteHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(@NonNull AthleteHolder holder, int position) {
//            Log.d(TAG, "In onBindViewHolder for position " + position);
            Athlete athlete = mAthlete.get(position);
            holder.bind(athlete);
        }

        @Override
        public int getItemCount() {
            return mAthlete.size();
        }

        public void setAthletes(List<Athlete> athletes) {
            mAthlete = athletes;
        }
    }
}
