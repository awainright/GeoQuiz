package Fitscore.database;

public class AthleteDbSchema {
    public static final class AthleteTable {
        public static final String NAME = "athletes";

        public static final class Cols {
            public static final String UUID = "uuid";
            public static final String FIRSTNAME = "firstname";
            public static final String LASTNAME = "lastname";
            public static final String GENDER = "gender";
            public static final String COMPLIANCE = "compliance";
            public static final String CLEAN = "clean";
            public static final String SNATCH = "snatch";
            public static final String BACKSQUAT = "backsquat";
            public static final String DEADLIFT = "deadlift";
            public static final String ROW = "row";
            public static final String RUN = "run";
            public static final String BODYWEIGHT = "bodyweight";
            public static final String FITSCORE = "fitscore";
        }
    }
}
