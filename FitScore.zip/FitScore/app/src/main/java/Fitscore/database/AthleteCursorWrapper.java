package Fitscore.database;

import Fitscore.Athlete;
import android.database.Cursor;
import android.database.CursorWrapper;

import java.util.UUID;

public class AthleteCursorWrapper extends CursorWrapper {
    /**
     * Creates a cursor wrapper.
     *
     * @param cursor The underlying cursor to wrap.
     */
    public AthleteCursorWrapper(Cursor cursor) {
        super(cursor);
    }

    public Athlete getAthlete() {
        String uuidString = getString(getColumnIndex(AthleteDbSchema.AthleteTable.Cols.UUID));
        String firstname = getString(getColumnIndex(AthleteDbSchema.AthleteTable.Cols.FIRSTNAME));
        String lastname = getString(getColumnIndex(AthleteDbSchema.AthleteTable.Cols.LASTNAME));
        String gender = getString(getColumnIndex(AthleteDbSchema.AthleteTable.Cols.GENDER));
        String compliance = getString(getColumnIndex(AthleteDbSchema.AthleteTable.Cols.COMPLIANCE));
        int clean = getInt(getColumnIndex(AthleteDbSchema.AthleteTable.Cols.CLEAN));
        int snatch = getInt(getColumnIndex(AthleteDbSchema.AthleteTable.Cols.SNATCH));
        int backsquat = getInt(getColumnIndex(AthleteDbSchema.AthleteTable.Cols.BACKSQUAT));
        int deadlift = getInt(getColumnIndex(AthleteDbSchema.AthleteTable.Cols.DEADLIFT));
        int row = getInt(getColumnIndex(AthleteDbSchema.AthleteTable.Cols.ROW));
        int run = getInt(getColumnIndex(AthleteDbSchema.AthleteTable.Cols.RUN));
        int bodyweight = getInt(getColumnIndex(AthleteDbSchema.AthleteTable.Cols.BODYWEIGHT));
        int fitscore = getInt(getColumnIndex(AthleteDbSchema.AthleteTable.Cols.FITSCORE));

        Athlete athlete = new Athlete(UUID.fromString(uuidString));
        athlete.setFirstName(firstname);
        athlete.setLastName(lastname);
        athlete.setGender(gender);
        athlete.setCompliance(compliance);
        athlete.setClean(clean);
        athlete.setSnatch(snatch);
        athlete.setBackSquat(backsquat);
        athlete.setDeadlift(deadlift);
        athlete.setRow(row);
        athlete.setRun(run);
        athlete.setBodyWeight(bodyweight);
        athlete.setFitScore(fitscore);


        return athlete;
    }

    private char getChar(int columnIndex) {
        return (char) columnIndex;
    }
}
