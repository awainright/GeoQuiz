package Fitscore;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.FileProvider;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;

import java.io.File;
import java.util.List;
import java.util.UUID;

import static android.widget.CompoundButton.OnClickListener;

public class AthleteFragment extends Fragment {

    private static final String ARG_ATHLETE_ID = "athlete_id";
    private static final String DIALOG_DATE = "DialogDate";

    private static final int REQUEST_CONTACT = 1;
    private static final int REQUEST_PHOTO = 2;

    private Athlete mAthlete;
    private File mPhotoFile;
    private EditText mFirstNameField;
    private EditText mLastNameField;
    private EditText mComplianceField;
    private EditText mCleanField;
    private EditText mSnatchField;
    private EditText mBacksquatField;
    private EditText mDeadliftField;
    private EditText mRowField;
    private EditText mRunField;
    private EditText mBodyweightField;
    private EditText mFitscoreField;

    private Button mFitButton;
    private ImageButton mPhotoButton;
    private ImageView mPhotoView;

    private Callbacks mCallbacks;

    public static AthleteFragment newInstance(UUID athleteId) {
        Bundle args = new Bundle();
        args.putSerializable(ARG_ATHLETE_ID, athleteId);

        AthleteFragment fragment = new AthleteFragment();
        fragment.setArguments(args);
        return fragment;
    }

    public interface Callbacks {
        void onAthleteUpdated(Athlete athlete);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mCallbacks = (Callbacks) context;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UUID athleteId = (UUID) getArguments().getSerializable(ARG_ATHLETE_ID);
        mAthlete = AthleteLab.get(getActivity()).getAthlete(athleteId);
        mPhotoFile = AthleteLab.get(getActivity()).getPhotoFile(mAthlete);
    }

    @Override
    public void onPause() {
        super.onPause();

        AthleteLab.get(getActivity()).updateAthlete(mAthlete);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_athlete, container, false);

        mFirstNameField = v.findViewById(R.id.athlete_firstname);
        mFirstNameField.setText(mAthlete.getFirstName());
        mFirstNameField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // No implementation
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mAthlete.setFirstName(s.toString());
                updateAthlete();
            }

            @Override
            public void afterTextChanged(Editable s) {
                // No implementation
            }
        });

        mLastNameField = v.findViewById(R.id.athlete_lastname);
        mLastNameField.setText(mAthlete.getLastName());
        mLastNameField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // No implementation
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mAthlete.setLastName(s.toString());
                updateAthlete();
            }

            @Override
            public void afterTextChanged(Editable s) {
                // No implementation
            }
        });

        mComplianceField = v.findViewById(R.id.athlete_compliance);
        mComplianceField.setText(mAthlete.getCompliance());
        mComplianceField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // No implementation
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mAthlete.setCompliance(s.toString());
                updateAthlete();
            }

            @Override
            public void afterTextChanged(Editable s) {
                // No implementation
            }
        });

        mCleanField = v.findViewById(R.id.athlete_clean);
        mCleanField.setText(Integer.toString(mAthlete.getClean()));
        mCleanField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // No implementation
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mAthlete.setClean(Integer.parseInt(s.toString()));
                updateAthlete();
            }

            @Override
            public void afterTextChanged(Editable s) {
                // No implementation
            }
        });

        mSnatchField = v.findViewById(R.id.athlete_snatch);
        mSnatchField.setText(Integer.toString(mAthlete.getSnatch()));
        mSnatchField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // No implementation
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mAthlete.setSnatch(Integer.parseInt(s.toString()));
                updateAthlete();
            }

            @Override
            public void afterTextChanged(Editable s) {
                // No implementation
            }
        });

        mBacksquatField = v.findViewById(R.id.athlete_backsquat);
        mBacksquatField.setText(Integer.toString(mAthlete.getBackSquat()));
        mBacksquatField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // No implementation
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mAthlete.setBackSquat(Integer.parseInt(s.toString()));
                updateAthlete();
            }

            @Override
            public void afterTextChanged(Editable s) {
                // No implementation
            }
        });

        mDeadliftField = v.findViewById(R.id.athlete_deadlift);
        mDeadliftField.setText(Integer.toString(mAthlete.getDeadlift()));
        mDeadliftField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // No implementation
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mAthlete.setDeadlift(Integer.parseInt(s.toString()));
                updateAthlete();
            }

            @Override
            public void afterTextChanged(Editable s) {
                // No implementation
            }
        });

        mRowField = v.findViewById(R.id.athlete_row);
        mRowField.setText(Integer.toString(mAthlete.getRow()));
        mRowField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // No implementation
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mAthlete.setRow(Integer.parseInt(s.toString()));
                updateAthlete();
            }

            @Override
            public void afterTextChanged(Editable s) {
                // No implementation
            }
        });

        mRunField = v.findViewById(R.id.athlete_run);
        mRunField.setText(Integer.toString(mAthlete.getRun()));
        mRunField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // No implementation
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mAthlete.setRun(Integer.parseInt(s.toString()));
                updateAthlete();
            }

            @Override
            public void afterTextChanged(Editable s) {
                // No implementation
            }
        });

        mBodyweightField = v.findViewById(R.id.athlete_bodyweight);
        mBodyweightField.setText(Integer.toString(mAthlete.getBodyWeight()));
        mBodyweightField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // No implementation
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mAthlete.setBodyWeight(Integer.parseInt(s.toString()));
                updateAthlete();
            }

            @Override
            public void afterTextChanged(Editable s) {
                // No implementation
            }
        });

        mFitscoreField = v.findViewById(R.id.athlete_fitscore);
        mFitscoreField.setText(Integer.toString(mAthlete.getFitScore()));
        mFitscoreField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // No implementation
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mAthlete.setFitScore(Integer.parseInt(s.toString()));
                updateAthlete();
            }

            @Override
            public void afterTextChanged(Editable s) {
                // No implementation
            }
        });

        mFitButton = v.findViewById(R.id.fitbutton);
        mFitButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                mFitscoreField.setText("4");
            }
        });


        PackageManager packageManager = getActivity().getPackageManager();

        mPhotoButton = v.findViewById(R.id.athlete_camera);
        final Intent captureImage = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        boolean canTakePhoto = mPhotoFile != null && captureImage.resolveActivity(packageManager) != null;
        mPhotoButton.setEnabled(canTakePhoto);

        mPhotoButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = FileProvider.getUriForFile(getActivity(), "com.bignerdranch.android.criminalintent.fileprovider", mPhotoFile);
                captureImage.putExtra(MediaStore.EXTRA_OUTPUT, uri);

                List<ResolveInfo> cameraActivities = getActivity().getPackageManager().queryIntentActivities(captureImage, PackageManager.MATCH_DEFAULT_ONLY);
                for (ResolveInfo activity : cameraActivities) {
                    getActivity().grantUriPermission(activity.activityInfo.packageName, uri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                }

                startActivityForResult(captureImage, REQUEST_PHOTO);
            }
        });

        mPhotoView = v.findViewById(R.id.athlete_photo);
        updatePhotoView();

        return v;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode != Activity.RESULT_OK) {
            return;
        } else if (requestCode == REQUEST_PHOTO) {
            Uri uri = FileProvider.getUriForFile(getActivity(), "com.bignerdranch.android.criminalintent.fileprovider", mPhotoFile);
            getActivity().revokeUriPermission(uri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            updateAthlete();
            updatePhotoView();
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mCallbacks = null;
    }

    private void updateAthlete() {
        AthleteLab.get(getActivity()).updateAthlete(mAthlete);
        mCallbacks.onAthleteUpdated(mAthlete);
    }


    private void updatePhotoView() {
        if (mPhotoFile == null || !mPhotoFile.exists()) {
            mPhotoView.setImageDrawable(null);
        } else {
            Bitmap bitmap = PictureUtils.getScaledBitmap(mPhotoFile.getPath(), getActivity());
            mPhotoView.setImageBitmap(bitmap);
        }
    }
}
